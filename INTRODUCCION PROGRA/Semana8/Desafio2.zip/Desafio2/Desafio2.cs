﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int numEmpleados;
        Console.Write("Ingrese el número de empleados: ");
        numEmpleados = int.Parse(Console.ReadLine());

        double sueldoTotal = 0;

        for (int i = 1; i <= numEmpleados; i++)
        {
            Console.WriteLine($"Empleado {i}");
            int numDias;
            Console.Write("Ingrese el número de días trabajados: ");
            numDias = int.Parse(Console.ReadLine());

            double horasTrabajadas = 0;
            for (int j = 1; j <= numDias; j++)
            {
                Console.Write($"Ingrese las horas trabajadas en el día {j}: ");
                horasTrabajadas += double.Parse(Console.ReadLine());
            }

            double sueldoSemanal = horasTrabajadas * 10; // suponiendo que se pagan 10 dólares por hora
            sueldoTotal += sueldoSemanal;

            Console.WriteLine($"El sueldo semanal del empleado {i} es de {sueldoSemanal} dólares.\n");
        }
        Console.WriteLine($"La empresa pagó un total de {sueldoTotal} dólares por los {numEmpleados} empleados.");
    }
}
